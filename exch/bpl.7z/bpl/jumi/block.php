<?php

namespace BPL\Jumi\Block;

require_once 'bpl/mods/block_unblock.php';

use function BPL\Mods\Block_Unblock\main as block;

block();